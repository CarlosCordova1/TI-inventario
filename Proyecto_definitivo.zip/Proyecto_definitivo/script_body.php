
<!-- JQuery validation para los campos-->
<script src="ArchivosJS/RecursosJS/additional-methods.min.js"></script>  
<script src="ArchivosJS/RecursosJS/jquery.validate.min.js"></script>  
<script src="ArchivosJS/EquipoCelular/equipoCelular.js"></script>
<script src="ArchivosJS/radio/radio.js"></script> 
<script src="ArchivosJS/InfLinea/infLinea.js"></script>  

  
<script src="ArchivosJS/Acce/Acce.js"></script> 
<script src="ArchivosJS/sim/sim.js"></script>
<script src="ArchivosJS/AcceCel/AcceCel.js"></script>


